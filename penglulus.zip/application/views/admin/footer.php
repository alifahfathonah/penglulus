	<footer class="footer">
		<div class="container">
		<p class="text-muted">&copy; <?=$this->fungsi->admin_konfigurasi()->tahun; ?> &middot; Tim IT <?=$this->fungsi->admin_konfigurasi()->sekolah; ?></p>
		</div>
	</footer>
    
    
</body>
</html>
